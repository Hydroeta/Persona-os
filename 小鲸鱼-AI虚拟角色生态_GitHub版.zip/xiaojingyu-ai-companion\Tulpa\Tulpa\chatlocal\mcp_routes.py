"""Browser-owned MCP settings; never registered as model-callable tools."""
from contextlib import asynccontextmanager
from urllib.parse import urlparse

import anyio
from fastapi import HTTPException, Request

from .mcp_access import MCPAccess, AccessDenied
from .mcp_server import MCPService
from .store import Store


def install_mcp_routes(app, store=None):
    store = store or Store()
    access = MCPAccess(store)
    service = MCPService(access)
    app.state.tulpa_mcp = service
    previous = app.router.lifespan_context

    @asynccontextmanager
    async def lifespan(application):
        async with previous(application):
            await anyio.to_thread.run_sync(service.start)
            try:
                yield
            finally:
                await anyio.to_thread.run_sync(service.stop)
    app.router.lifespan_context = lifespan

    def local(request, write=False):
        if request.client and request.client.host not in ('127.0.0.1', '::1', 'testclient'):
            raise HTTPException(403)
        if urlparse(str(request.base_url)).hostname not in ('127.0.0.1', 'localhost', '::1', 'testserver'):
            raise HTTPException(403)
        if request.headers.get('origin') not in (None, str(request.base_url).rstrip('/')) or request.headers.get('sec-fetch-site') == 'cross-site':
            raise HTTPException(403)
        if write and (request.headers.get('x-chatweave-ui') != '1' or request.headers.get('content-type', '').split(';')[0] != 'application/json'):
            raise HTTPException(403)
        if urlparse(str(request.base_url)).hostname != 'testserver':
            service.source_base = str(request.base_url).rstrip('/')

    @app.get('/api/mcp')
    def status(request: Request):
        local(request)
        with store.connect() as db:
            platforms={r[0]:r[1] for r in db.execute('SELECT platform,count(*) FROM messages GROUP BY platform')}
        from .desktop_routes import read_product_settings
        settings=read_product_settings()
        return dict(**service.status(), **access.list(), storage_label=store.path.parent.parent.name,
                    data_platforms=platforms, onebot_configured=bool(settings['sender_url']))

    @app.put('/api/mcp')
    def configure(request: Request, body: dict):
        local(request, True)
        if set(body) != {'enabled', 'port'}:
            raise HTTPException(400, 'MCP 配置字段无效。')
        try:
            old = access.settings()
            access.configure(body['enabled'], body['port'])
            if not body['enabled'] or body['port'] != old['port']:
                service.stop()
            if body['enabled']:
                service.start()
            return service.status()
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from None

    @app.post('/api/mcp/connections')
    def create(request: Request, body: dict):
        local(request, True)
        try:
            if not isinstance(body.get('platforms'),list) or any(p not in ('qq','wechat') for p in body['platforms']):
                raise ValueError('请选择允许访问的平台。')
            with store.connect() as db:
                for platform in body.get('platforms',[]):
                    if platform=='qq' and body.get('chat') is True and body.get('send') is True:continue
                    if not db.execute('SELECT 1 FROM messages WHERE platform=? LIMIT 1',(platform,)).fetchone():
                        raise ValueError('请先导入所选平台的聊天，确认来源账号后再创建连接。')
            return access.create(body)
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from None

    def token_for(body):
        if set(body)!={'token'} or not isinstance(body['token'],str):raise HTTPException(400,'连接凭据字段无效。')
        try:return access.authorize(body['token'])
        except AccessDenied as exc:raise HTTPException(400,str(exc)) from None

    @app.post('/api/mcp/test')
    async def test(request:Request,body:dict):
        local(request,True);token_for(body)
        if not service.status()['running']:raise HTTPException(400,'请先启动本机 MCP 服务。')
        from .mcp_connect import test_connection
        try:
            with anyio.fail_after(25):result=await test_connection(service.status()['url'],body['token'])
            token_for(body)
            return result
        except HTTPException:raise
        except Exception:raise HTTPException(400,'连接检测未通过。请检查服务是否运行、端口和授权是否有效。') from None

    @app.post('/api/mcp/connections/{gid}/codex')
    def connect_codex(gid:str,request:Request,body:dict):
        local(request,True);grant=token_for(body)
        if grant['id']!=gid:raise HTTPException(403)
        if not service.status()['running']:raise HTTPException(400,'请先启动本机 MCP 服务。')
        from .mcp_connect import install_codex
        try:return install_codex(service.status()['url'],body['token'],scope=grant['scope'])
        except ValueError as exc:raise HTTPException(409,str(exc)) from None
        except OSError:raise HTTPException(400,'无法写入本机 Codex 配置，请使用复制配置方式。') from None

    @app.post('/api/mcp/connections/{gid}/revoke')
    def revoke(gid: str, request: Request, body: dict):
        local(request, True)
        service.tools.chat.stop_all(gid, '连接已撤销')
        service.tools.actions.revoke(gid)
        service.cancel(gid)
        return dict(revoked=True)

    @app.get('/api/mcp/operations')
    def operations(request: Request):
        local(request)
        return dict(operations=service.tools.actions.list())

    @app.get('/api/mcp/chats')
    def chats(request: Request):
        local(request)
        return dict(sessions=service.tools.chat.listed(),receiver=service.tools.chat.receiver.status())

    @app.get('/api/mcp/chat-overview')
    def chat_overview(request: Request):
        local(request)
        return service.tools.chat.learning.overview()

    @app.get('/api/mcp/chat-library')
    def chat_library(request: Request,conversation_id: str):
        local(request)
        try:return service.tools.chat.learning.library(conversation_id,records=True)
        except ValueError as exc:raise HTTPException(400,'无法读取该群的学习记录，请检查当前 QQ 连接与群授权。') from exc

    @app.post('/api/mcp/chat-library')
    def change_library(request: Request,body: dict):
        local(request,True)
        cid=body.get('conversation_id');change=body.get('change')
        if set(body)!={'conversation_id','change'} or not isinstance(cid,str) or not isinstance(change,dict):raise HTTPException(400,'学习设置无效')
        try:return service.tools.chat.learning.library_change(cid,change)
        except ValueError as exc:
            message=('预算须为 2–100 的整数；其他设置请检查是否有效。' if str(exc)=='invalid_setting'
                     else '未能保存，请检查当前群授权和条目是否仍存在。')
            raise HTTPException(400,message) from exc

    @app.get('/api/mcp/chat-personas')
    def chat_personas(request: Request):
        local(request)
        from .mcp_chat_prompts import persona_catalog
        return persona_catalog()

    @app.post('/api/mcp/chats/start')
    def start_chat(request: Request,body: dict):
        local(request,True)
        if set(body)!={'connection_id','conversation_id','persona_preset','idempotency_key'}:raise HTTPException(400,'开始参数无效')
        try:
            import threading
            grant=access.by_id(body['connection_id'],source=False)
            with access.connect() as db:
                existing={r['id']:r['last_contact'] for r in db.execute('SELECT id,last_contact FROM chat_sessions WHERE active=1')}
            result=service.tools.chat.start(grant,{k:v for k,v in body.items() if k!='connection_id'},threading.Event())
            # A click starts a server session, not an external model heartbeat.
            sid=result['session']['id']
            with access.connect() as db:db.execute('UPDATE chat_sessions SET last_contact=? WHERE id=?',(existing.get(sid,0),sid))
            state=service.tools.chat.learning.status(sid,grant['id'])
            note='已开启会话并接续原群积累。请在已连接的 Agent 中开始或继续该群聊天；无须另开学习或粘贴学习指令。'
            if not state['enabled']:note+=' 这个账号和群此前已暂停学习，仍保持关闭，可在学习记录的高级设置恢复。'
            return dict(session_id=sid,note=note)
        except ValueError as exc:raise HTTPException(400,str(exc)) from None

    @app.get('/api/mcp/live-groups')
    def live_groups(request: Request):
        local(request)
        from .onebot import Client
        try:
            client=Client(timeout=4); account=client.login()
            rows=client.call('get_group_list', {})
            return dict(items=[dict(platform='qq',conversation_id=f'{account}:group:{r["group_id"]}',name=str(r.get('group_name') or r['group_id']),count='OneBot')
                               for r in rows if isinstance(r,dict) and str(r.get('group_id','')).isdigit()])
        except ValueError as exc:raise HTTPException(400,str(exc)) from None

    @app.get('/api/mcp/chats/{sid}/learning')
    def learning_status(sid: str, request: Request):
        local(request)
        try:
            row=service.tools.chat.row(sid)
            return service.tools.chat.learning.status(sid,row['grant_id'],records=True)
        except ValueError as exc:raise HTTPException(400,str(exc)) from None

    @app.put('/api/mcp/chats/{sid}/learning')
    def learning_configure(sid: str, request: Request, body: dict):
        local(request,True)
        try:return service.tools.chat.learning.configure(sid,body)
        except ValueError as exc:raise HTTPException(400,str(exc)) from None

    @app.post('/api/mcp/chats/{sid}/learning/record')
    def learning_record(sid: str, request: Request, body: dict):
        local(request,True)
        try:return service.tools.chat.learning.manage(sid,body)
        except ValueError as exc:raise HTTPException(400,str(exc)) from None

    @app.post('/api/mcp/chats/{sid}/stop')
    def stop_chat(sid: str, request: Request, body: dict):
        local(request, True)
        if body:raise HTTPException(400, '停止操作不接受额外参数。')
        try:
            if sid=='all':return service.tools.chat.stop_all()
            return service.tools.chat.stop(sid)
        except ValueError as exc:raise HTTPException(404,str(exc)) from None

    @app.get('/api/mcp/conversations')
    def conversations(request: Request, query: str='', offset: int=0):
        local(request)
        if len(query) > 100 or offset < 0:
            raise HTTPException(400)
        with store.connect() as db:
            rows = [dict(r) for r in db.execute('''SELECT platform,conversation_id,max(conversation) name,count(*) count
                FROM messages WHERE instr(lower(conversation),lower(?))>0
                GROUP BY platform,conversation_id ORDER BY platform,name LIMIT 81 OFFSET ?''', (query, offset))]
        return dict(items=rows[:80], has_more=len(rows)>80, next_offset=offset+80)

    return service
